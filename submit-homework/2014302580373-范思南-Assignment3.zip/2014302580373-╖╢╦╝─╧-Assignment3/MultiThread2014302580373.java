import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class MultiThread2014302580373 implements Runnable {
	public int j;
	
	public  MultiThread2014302580373(int i){
		j = i;
	}
	
	@Override
	public void run() {
		// TODO �Զ����ɵķ������
		try {
			Document doc = Jsoup.connect("http://www.wpi.edu/academics/cs/research-interests.html").timeout(10000).get();
			Elements linksAll = doc.select("a[href][title]:matches(\\b\\w*\\s\\w*\\b)");
			Document doc0 = Jsoup.connect(linksAll.get(j).attr("href")).timeout(10000).get();
			Elements name = doc0.select("h2:matches(\\b\\w*\\s\\w*\\b)");
			Elements information = doc0.select("p:matches(\\d-\\d{3}-\\d{3}-\\d{4})");

			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teacher", "root", "fan19960408");
			java.sql.Statement stmt = conn.createStatement();
			stmt.executeUpdate("insert into teacher(name,information)values('" + name.text() + "','"
					+ information.get(0).text() + "')");
			conn.close();

		} catch (IOException | ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}

	}

}
