import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;



public class Main2014302580373 {
	
	public static int i=2;

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		double time0 = System.currentTimeMillis();
		try 
		{
			Document doc = Jsoup.connect("http://www.wpi.edu/academics/cs/research-interests.html").timeout(10000).get();			
			Elements linksAll = doc.select("a[href][title]:matches(\\b\\w*\\s\\w*\\b)");
			for(int i=2;i<16;i++)
			{
				Document doc0 = Jsoup.connect(linksAll.get(i).attr("href")).timeout(10000).get();
				Elements name = doc0.select("h2:matches(\\b\\w*\\s\\w*\\b)");
				Elements information = doc0.select("p:matches(\\d-\\d{3}-\\d{3}-\\d{4})");
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/teacher", "root", "fan19960408");
				java.sql.Statement stmt = conn.createStatement();
				stmt.executeUpdate("insert into teacher(name,information)values('" + name.text()+ "','" + information.get(0).text() +"')");
				conn.close();
			}
		} 
		catch (IOException e) 
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		double time1 = System.currentTimeMillis();
		System.out.println("���߳���ʱ��"+(time1-time0)+"ms");
		
		
		double time2 = System.currentTimeMillis();
		Thread[] thread = new Thread[14];
		for(Thread tt: thread)
		{
			tt = new Thread(new MultiThread2014302580373(Main2014302580373.i++));	
			tt.start();
		}
		double time3 = System.currentTimeMillis();
		System.out.println("���߳���ʱ��"+(time3-time2)+"ms");
	}

}
